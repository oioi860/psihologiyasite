<?php
// telegram.php - Прокси для отправки сообщений в Telegram
// Установка заголовков для CORS
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Ваши данные
$token = "8258895962:AAGYfPzf0MU6_EYq-L-BTBIgQX5wov18yMw";
$chat_id = "614419745";

// Получаем данные из POST-запроса
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

// Проверяем, что поля не пустые
if (empty($name) || empty($message)) {
    echo json_encode([
        'ok' => false, 
        'error' => 'Заполните все поля'
    ]);
    exit;
}

// Формируем красивое сообщение
$text = "🆕 <b>НОВАЯ ЗАЯВКА С САЙТА</b>\n\n";
$text .= "━━━━━━━━━━━━━━━\n";
$text .= "👤 <b>Имя:</b> " . htmlspecialchars($name) . "\n";
$text .= "📝 <b>Запрос:</b> " . htmlspecialchars($message) . "\n";
$text .= "━━━━━━━━━━━━━━━\n\n";
$text .= "📅 <b>Дата:</b> " . date('d.m.Y') . "\n";
$text .= "⏰ <b>Время:</b> " . date('H:i:s') . "\n";
$text .= "━━━━━━━━━━━━━━━";

// Отправляем запрос к Telegram API
$url = "https://api.telegram.org/bot{$token}/sendMessage";

$data = [
    'chat_id' => $chat_id,
    'text' => $text,
    'parse_mode' => 'HTML',
    'disable_web_page_preview' => true
];

$options = [
    'http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => http_build_query($data)
    ]
];

$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);

if ($result) {
    $response = json_decode($result, true);
    if ($response['ok']) {
        echo json_encode(['ok' => true]);
    } else {
        echo json_encode(['ok' => false, 'error' => 'Ошибка Telegram API']);
    }
} else {
    echo json_encode(['ok' => false, 'error' => 'Ошибка соединения']);
}
?>